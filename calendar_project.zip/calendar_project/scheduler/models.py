from django.db import models

class Schedule(models.Model):
    # Flaskのテーブル構造をそのまま移植
    date = models.DateField()
    title = models.CharField(max_length=200)
    detail = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.title