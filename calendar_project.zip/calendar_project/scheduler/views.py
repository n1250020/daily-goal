from django.shortcuts import render, redirect, get_object_or_404
from .models import Schedule
import calendar
import datetime

def index(request, year=None, month=None):
    # 1. 今日の日付と表示する年月を設定
    today = datetime.date.today()
    year = year or today.year
    month = month or today.month

    # 2. カレンダー生成（日曜始まり）
    cal = calendar.Calendar(calendar.SUNDAY).monthdayscalendar(year, month)

    # 3. 前月・翌月の計算
    prev_month = month - 1
    prev_year = year
    if prev_month == 0:
        prev_month = 12
        prev_year -= 1

    next_month = month + 1
    next_year = year
    if next_month == 13:
        next_month = 1
        next_year += 1

    # 4. データベースからその月の予定を取得 (Django ORM)
    # date__year, date__month という指定で簡単にフィルタリング可能
    db_schedules = Schedule.objects.filter(date__year=year, date__month=month)

    # 5. テンプレートで扱いやすいように辞書にまとめる
    schedules = {}
    for item in db_schedules:
        day = item.date.day
        if day not in schedules:
            schedules[day] = []
        schedules[day].append(item)

    # 6. テンプレートへデータを渡す
    context = {
        'calendar': cal,
        'year': year,
        'month': month,
        'prev_year': prev_year,
        'prev_month': prev_month,
        'next_year': next_year,
        'next_month': next_month,
        'today': today,
        'schedules': schedules,
    }
    return render(request, 'scheduler/calendar.html', context)

def add_schedule(request):
    """予定の追加処理"""
    if request.method == "POST":
        date_str = request.POST.get("date")
        title = request.POST.get("title")
        detail = request.POST.get("detail")

        # データベースに保存
        Schedule.objects.create(
            date=date_str,
            title=title,
            detail=detail
        )
        
        # 保存後、元の年月のページにリダイレクト
        y, m, _ = map(int, date_str.split("-"))
        return redirect('index_with_date', year=y, month=m)
    
    return redirect('index')

def schedule_detail(request, id):
    """予定の詳細表示"""
    # 指定したIDがなければ404エラーを返す便利な関数
    schedule = get_object_or_404(Schedule, id=id)
    return render(request, 'scheduler/detail.html', {'schedule': schedule})

def update_schedule(request):
    """予定の更新処理"""
    if request.method == "POST":
        id = request.POST.get("id")
        schedule = get_object_or_404(Schedule, id=id)
        
        # データの更新
        schedule.title = request.POST.get("title")
        schedule.detail = request.POST.get("detail")
        schedule.save() # これだけでDBが更新される
        
    return redirect('index')