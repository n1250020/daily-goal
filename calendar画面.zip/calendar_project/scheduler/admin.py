from django.contrib import admin
from .models import Schedule
from .models import Notification

admin.site.register(Schedule)
admin.site.register(Notification)