from django.urls import path, include  # include を追加

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('<int:year>/<int:month>/', views.index, name='index_with_date'),
    path('add/', views.add_schedule, name='add_schedule'),
    path('schedule/<int:id>/', views.schedule_detail, name='detail'),
    path('update/', views.update_schedule, name='update_schedule'),
    
    # ▼ django-webpush用のパスを追加
    path('webpush/', include('webpush.urls')),
]