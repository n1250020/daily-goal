from django.shortcuts import render, redirect, get_object_or_404
from .models import Schedule
import calendar
import datetime
from .models import Notification # 追加
from django.utils.dateparse import parse_datetime
from django.contrib import messages # メッセージを表示したい場合
# views.py
from webpush.models import Group

def index(request, year=None, month=None):
    # ユーザーがログインしている場合、通知グループに追加する
    if request.user.is_authenticated:
        group, created = Group.objects.get_or_create(name="all_users")
        group.user_set.add(request.user)
    
    # ... (これまでのカレンダー表示ロジック) ...

def index(request, year=None, month=None):
    # 1. 今日の日付と表示する年月を設定
    today = datetime.date.today()
    year = year or today.year
    month = month or today.month

    # 2. カレンダー生成（日曜始まり）
    cal = calendar.Calendar(calendar.SUNDAY).monthdayscalendar(year, month)

    # 3. 前月・翌月の計算
    prev_month = month - 1
    prev_year = year
    if prev_month == 0:
        prev_month = 12
        prev_year -= 1

    next_month = month + 1
    next_year = year
    if next_month == 13:
        next_month = 1
        next_year += 1

    # 4. データベースからその月の予定を取得 (Django ORM)
    # date__year, date__month という指定で簡単にフィルタリング可能
    db_schedules = Schedule.objects.filter(date__year=year, date__month=month)

    # 5. テンプレートで扱いやすいように辞書にまとめる
    schedules = {}
    for item in db_schedules:
        day = item.date.day
        if day not in schedules:
            schedules[day] = []
        schedules[day].append(item)

# --- ここから PHP の通知保存ロジックを移植 ---
    if request.method == 'POST' and 'set_notification' in request.POST:
        set_time = request.POST.get('scheduled_time')
        set_message = request.POST.get('notification_message')

        if set_time and set_message:
            # parse_datetime で文字列をPythonの日時オブジェクトに変換
            scheduled_at = parse_datetime(set_time)
            
            if scheduled_at:
                Notification.objects.create(
                    message=set_message,
                    scheduled_at=scheduled_at,
                    is_sent=False
                )
                # PHPの $message_log = "通知を予約しました。" に相当
                messages.success(request, "通知を予約しました！")
            else:
                messages.error(request, "日時の形式が正しくありません。")

    # --- 後半の context 渡しもそのまま ---

    # 6. テンプレートへデータを渡す
    context = {
        'calendar': cal,
        'year': year,
        'month': month,
        'prev_year': prev_year,
        'prev_month': prev_month,
        'next_year': next_year,
        'next_month': next_month,
        'today': today,
        'schedules': schedules,
    }

    # # PHPの「通知セット」ロジックの移植
    # if request.method == 'POST' and 'set_notification' in request.POST:
    #     set_time = request.POST.get('scheduled_time')
    #     set_message = request.POST.get('notification_message')
        
    #     if set_time and set_message:
    #         # 文字列を日時に変換して保存
    #         Notification.objects.create(
    #             message=set_message,
    #             scheduled_at=parse_datetime(set_time),
    #             is_sent=False
    #         )
    #         # 成功メッセージなどを渡す場合は context に追加
    return render(request, 'scheduler/calendar.html', context)

# def add_schedule(request):
#     """予定の追加処理"""
#     if request.method == "POST":
#         date_str = request.POST.get("date")
#         title = request.POST.get("title")
#         detail = request.POST.get("detail")

#         # データベースに保存
#         Schedule.objects.create(
#             date=date_str,
#             title=title,
#             detail=detail,
#                 notifications=date_str
#         )
def add_schedule(request):
    if request.method == "POST":
        date_str = request.POST.get("date")
        title = request.POST.get("title")
        
        # 1. 予定を保存
        new_schedule = Schedule.objects.create(
            date=date_str,
            title=title,
            detail=request.POST.get("detail")
        )

        # 2. 「notifications」という変数に、後で通知を送るための情報をセットする例
        # 例えば、予定のタイトルと日付をセットにして管理する
        notifications = f"通知予約完了: {date_str} の「{title}」"
        
        # 本来はここで「通知用テーブル」に保存したり、
        # 外部のプッシュ通知サービスにデータを送ったりします。
        
        # 保存後、元の年月のページにリダイレクト
        y, m, _ = map(int, date_str.split("-"))
        return redirect('index_with_date', year=y, month=m)
    
    return redirect('index')

def schedule_detail(request, id):
    """予定の詳細表示"""
    # 指定したIDがなければ404エラーを返す便利な関数
    schedule = get_object_or_404(Schedule, id=id)
    return render(request, 'scheduler/detail.html', {'schedule': schedule})

def update_schedule(request):
    """予定の更新処理"""
    if request.method == "POST":
        id = request.POST.get("id")
        schedule = get_object_or_404(Schedule, id=id)
        
        # データの更新
        schedule.title = request.POST.get("title")
        schedule.detail = request.POST.get("detail")
        schedule.save() # これだけでDBが更新される
        
    return redirect('index')