from django.db import models
from django.contrib.auth.models import User # Django標準のユーザー機能を利用

class Notification(models.Model):
    # 誰に対する通知か（デフォルトで1番目のユーザーに関連付け）
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=1)
    
    # PHPの $set_message に相当
    message = models.TextField(verbose_name="通知内容")
    
    # PHPの $set_time に相当（予定時刻）
    scheduled_at = models.DateTimeField(verbose_name="通知予定時刻")
    
    # PHPの is_sent=0 に相当（送ったかどうか）
    is_sent = models.BooleanField(default=False, verbose_name="送信済みフラグ")
    
    # 登録日時（いつこの予約を作ったか自動記録）
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.scheduled_at}] {self.message[:15]}"

class Schedule(models.Model):
    # Flaskのテーブル構造をそのまま移植
    date = models.DateField()
    title = models.CharField(max_length=200)
    detail = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.title