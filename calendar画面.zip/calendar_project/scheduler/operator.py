from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore
from datetime import datetime
from .models import Notification
# operator.py の修正
from webpush import send_group_notification

def send_notifications():
    now = datetime.now()
    pending_notifications = Notification.objects.filter(is_sent=False, scheduled_at__lte=now)

    for note in pending_notifications:
        # 登録されている全ユーザーに通知を飛ばす（グループ通知の例）
        payload = {"title": "予定の時間です！", "body": note.message}
        send_group_notification(group_name="all_users", payload=payload)
        
        note.is_sent = True
        note.save()

# def send_notifications():
#     """1分ごとに実行される関数"""
#     now = datetime.now()
#     # まだ送られていない(is_sent=False)、かつ、予定時刻を過ぎた通知を取得
#     pending_notifications = Notification.objects.filter(is_sent=False, scheduled_at__lte=now)

#     for note in pending_notifications:
#         # ここで実際に通知を送る処理（今回はコンソール表示）
#         print(f"🔔通知を送信: {note.message}")
        
#         # 本来はここにWeb Pushの送信コードを書く
        
#         # 送信済みに更新
#         note.is_sent = True
#         note.save()

def start():
    """スケジューラを開始する"""
    scheduler = BackgroundScheduler()
    scheduler.add_jobstore(DjangoJobStore(), "default")
    
    # 1分ごとに send_notifications を実行
    scheduler.add_job(send_notifications, 'interval', minutes=1, name='check_notifications', jobstore='default', replace_existing=True)
    
    scheduler.start()