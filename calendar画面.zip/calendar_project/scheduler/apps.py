from django.apps import AppConfig

class SchedulerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scheduler' # あなたのアプリ名に合わせてください

    def ready(self):
        # Djangoが起動したときに一度だけ実行される
        from . import operator
        operator.start()


class SchedulerConfig(AppConfig):
    name = 'scheduler'
