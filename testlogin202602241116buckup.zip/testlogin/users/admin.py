from django.contrib import admin
from .models import Avatar, AvatarItem  # 「.」は同じフォルダという意味です
# もしNotificationsが別のファイルにあるならそれも書く
from .models_remote import Notifications
from .models import Schedule

admin.site.register(Schedule)

# --- 既存の Notifications 設定 ---
@admin.register(Notifications)
class NotificationsAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_id', 'message', 'scheduled_at', 'is_sent')
    search_fields = ('message',)
    list_filter = ('is_sent', 'scheduled_at')

# --- ここから Avatar の設定を追記 ---
@admin.register(Avatar)
class AvatarAdmin(admin.ModelAdmin):
    # 管理画面で見やすいように項目を並べる
    list_display = ('user', 'points', 'face_type', 'eye_type', 'mouth_type', 'updated_at')
    # ユーザー名で検索できるようにする
    search_fields = ('user__username',)

# AvatarItem（ショップのアイテム）を登録
admin.site.register(AvatarItem)