from flask import Flask, render_template, request, redirect, url_for
import calendar
import datetime

app = Flask(__name__)

import sqlite3

def init_db():
    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT,
            title TEXT,
            detail TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_to_db(date, title, detail):
    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT,
            title TEXT,
            detail TEXT
        )
    """)
    cur.execute(
        "INSERT INTO schedule (date, title, detail) VALUES (?, ?, ?)",
        (date, title, detail)
    )
    conn.commit()
    conn.close()

def load_from_db(year, month):
    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute("""
        SELECT id, date, title FROM schedule
        WHERE date LIKE ?
    """, (f"{year:04d}-{month:02d}-%",))
    rows = cur.fetchall()
    conn.close()

    schedules = {}
    for id_, date, title in rows:
        day = int(date.split("-")[2])  # ← 日だけ取り出す
        schedules.setdefault(day, []).append({
            "id": id_,
            "title": title
        })

    return schedules

@app.route("/")
@app.route("/<int:year>/<int:month>")
def index(year=None, month=None):

    # 今日の日付
    today = datetime.date.today()

    # 年月が指定されていなければ今月
    if year is None or month is None:
        year = today.year
        month = today.month

    # カレンダー生成（日曜始まり）
    cal = calendar.Calendar(calendar.SUNDAY).monthdayscalendar(year, month)

    # 前月・翌月計算
    prev_year, prev_month = year, month - 1
    next_year, next_month = year, month + 1

    if prev_month == 0:
        prev_month = 12
        prev_year -= 1

    if next_month == 13:
        next_month = 1
        next_year += 1

    schedules = load_from_db(year, month)

    return render_template(
        "calendar.html",
        calendar=cal,
        year=year,
        month=month,
        prev_year=prev_year,
        prev_month=prev_month,
        next_year=next_year,
        next_month=next_month,
        today=today,
        schedules=schedules
    )

@app.route("/add_schedule", methods=["POST"])
def add_schedule():
    date = request.form.get("date")
    title = request.form.get("title")
    detail = request.form.get("detail")

    save_to_db(date, title, detail)

    year, month, _ = map(int, date.split("-"))
    return redirect(url_for("index", year=year, month=month))

#予定詳細表示
@app.route("/schedule/<int:id>")
def schedule_detail(id):
    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute(
        "SELECT id, date, title, detail FROM schedule WHERE id = ?",
        (id,)
    )
    schedule = cur.fetchone()
    conn.close()

    return render_template("detail.html", schedule=schedule)

#予定更新
@app.route("/update_schedule", methods=["POST"])
def update_schedule():
    id = request.form.get("id")
    title = request.form.get("title")
    detail = request.form.get("detail")

    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute(
        "UPDATE schedule SET title = ?, detail = ? WHERE id = ?",
        (title, detail, id)
    )
    conn.commit()
    conn.close()

    return redirect("/")

#アプリ起動
if __name__ == "__main__":
    init_db()
    app.run(debug=True)