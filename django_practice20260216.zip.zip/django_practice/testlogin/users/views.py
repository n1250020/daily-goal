import calendar
from datetime import date
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.contrib.auth.views import PasswordResetView
from django.contrib.auth.decorators import login_required
# 一番上のインポートに追加
from django.contrib.auth import logout # ←これを追加

# モデルとフォームのインポート
from .models import Avatar, Schedule
from .forms import SignUpForm

from .models import Avatar # ポイント保存先



# 共通のリダイレクト先
REDIRECT_URL = '/calendar/'

# =========================
# 認証系 (ログイン・新規登録)
# =========================

def index(request):
    """ログイン画面"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect(REDIRECT_URL)
        else:
            return render(request, 'users/login.html', {
                'error': 'ユーザー名かパスワードが間違っています'
            })
    return render(request, 'users/login.html')

def home(request):
    """ホーム画面の交通整理"""
    if request.user.is_authenticated:
        return redirect(REDIRECT_URL)
    return redirect('login')

def signup(request):
    """新規登録"""
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect(REDIRECT_URL)
    else:
        form = SignUpForm()
    return render(request, 'users/signup.html', {'form': form})

# --- 中略 ---

@login_required
def logout_view(request):
    """ログアウト処理"""
    logout(request)
    return redirect('login') # ログアウトしたらログイン画面へ

# =========================
# カレンダー・予定管理
# =========================

@login_required
def calendar_view(request, year=None, month=None):
    """カレンダー表示（予定の読み込み）"""
    today = date.today()
    year = int(year) if year else today.year
    month = int(month) if month else today.month

    cal = calendar.Calendar(firstweekday=6)
    month_days = cal.monthdayscalendar(year, month)

    if month == 1:
        prev_year, prev_month = year - 1, 12
    else:
        prev_year, prev_month = year, month - 1
        
    if month == 12:
        next_year, next_month = year + 1, 1
    else:
        next_year, next_month = year, month + 1

    # 今月の予定を取得
    schedule_queryset = Schedule.objects.filter(
        user=request.user, 
        date__year=year, 
        date__month=month
    )

    # 【重要】今月の合計レベル（経験値）を計算
    # 例：レベル1の予定=10EXP, レベル2=20EXP... と計算する場合
    total_exp = 0
    for s in schedule_queryset:
        total_exp += (s.level * 10) # 1つの予定につき レベル×10 の経験値

    # 現在のレベルを計算（例：100EXPで1レベルアップ）
    current_lv = (total_exp // 100) + 1
    display_exp = total_exp % 100 # ゲージに表示する端数

    schedules = {}
    for s in schedule_queryset:
        day = s.date.day
        if day not in schedules:
            schedules[day] = []
        schedules[day].append(s)

    context = {
        'calendar': month_days,
        'year': year,
        'month': month,
        'today': today,
        'prev_year': prev_year, 'prev_month': prev_month,
        'next_year': next_year, 'next_month': next_month,
        'schedules': schedules,
        'current_lv': current_lv,   # 算出したレベル
        'display_exp': display_exp, # ゲージの進捗
    }
    return render(request, 'users/calendar.html', context)

@login_required
def add_schedule(request):
    """予定を新規保存"""
    if request.method == 'POST':
        title = request.POST.get('title')
        #description = request.POST.get('detail')
        detail_text = request.POST.get('detail')
        date_str = request.POST.get('date')
        level = request.POST.get('level', 1) # ★レベルを取得

        if title and date_str:
            Schedule.objects.create(
                user=request.user,
                title=title,
                #description=description,
                description=detail_text, # ← ここを修正
                date=date_str,
                level=level # レベル
            )
    return redirect('calendar')

@login_required
def schedule_detail(request, pk):
    """予定の詳細表示 (HTML)"""
    # ここを JsonResponse から render に変更
    schedule = get_object_or_404(Schedule, pk=pk, user=request.user)
    return render(request, 'users/schedule_detail.html', {'schedule': schedule})

@login_required
def update_schedule(request):
    """予定の更新処理"""
    if request.method == 'POST':
        schedule_id = request.POST.get('id')
        schedule = get_object_or_404(Schedule, id=schedule_id, user=request.user)
        
        schedule.title = request.POST.get('title')
        schedule.description = request.POST.get('detail') 
        schedule.level = request.POST.get('level', 1) # ★レベルを更新
        schedule.save()
        
    return redirect('calendar')

@login_required
def delete_schedule(request, pk):
    """予定の削除処理"""
    if request.method == 'POST':
        schedule = get_object_or_404(Schedule, pk=pk, user=request.user)
        schedule.delete()
    return redirect('calendar')

# =========================
# その他機能
# =========================

@login_required
def avatar_edit(request):
    """アバター編集"""
    avatar, created = Avatar.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        avatar.back_type = request.POST.get('back_type', 1)
        avatar.clothes_type = request.POST.get('clothes_type', 1)
        avatar.face_type = request.POST.get('face_type', 1)
        avatar.save()
        return redirect(REDIRECT_URL)
    return render(request, 'users/avatar_edit.html', {'avatar': avatar})

def check_username(request):
    """ユーザー名重複チェック"""
    username = request.GET.get("username", "").strip()
    exists = User.objects.filter(username=username).exists()
    return JsonResponse({"exists": exists})

class CustomPasswordResetView(PasswordResetView):
    """パスワード再設定"""
    template_name = 'users/password_reset.html'
    success_url = '/password_reset/done/'

    def form_valid(self, form):
        email = form.cleaned_data['email']
        try:
            user = User.objects.get(email=email)
            self.request.session['reset_username'] = user.username
        except User.DoesNotExist:
            self.request.session['reset_username'] = None
        return super().form_valid(form)
    # =========================
# ショップ画面（追加分）
# =========================
from .models import AvatarItem  # モデルのインポートが必要なため追記

@login_required
def shop_view(request):
    # ログインユーザーのアバター情報を取得
    avatar, created = Avatar.objects.get_or_create(user=request.user)
    
    # ユーザーが既に持っているアイテムのIDリストを取得
    owned_item_ids = avatar.owned_items.values_list('id', flat=True)
    
    # まだ持っていないアイテムだけをショップに並べる
    unowned_items = AvatarItem.objects.exclude(id__in=owned_item_ids)

    # テンプレートのパスを 'users/shop.html' に修正しました
    return render(request, 'users/shop.html', {
        'avatar': avatar,
        'unowned_items': unowned_items,
    })

# =========================
# アイテム購入処理（追加分）
# =========================
@login_required
def buy_item(request):
    if request.method == "POST":
        item_id = request.POST.get('item_id')
        item = get_object_or_404(AvatarItem, id=item_id)
        avatar = Avatar.objects.get(user=request.user)

        # ポイントが足りるかチェック
        if avatar.points >= item.price:
            avatar.points -= item.price      # ポイントを引く
            avatar.owned_items.add(item)     # 持ち物リストに追加
            avatar.save()
            # 購入成功：ショップ画面へリダイレクト
            return redirect('avatar_shop')
        else:
            # ポイント不足の場合
            return redirect('avatar_shop')
    
    return redirect('avatar_shop')


def gain_exp_api(request):
    if request.method == 'POST':
        # ログイン中のユーザーのアバターデータを取得
        avatar, created = Avatar.objects.get_or_create(user=request.user)
        
        # 経験値を20増やす（例）
        # ※本来はAvatarモデルにexpカラムがあると良いですが、
        #   今は暫定的にpointsを経験値として扱うか、Avatarモデルにexpを追加してください。
        avatar.points += 20 
        avatar.save()
        
        # 現在のレベルを計算して返す
        new_lv = (avatar.points // 100) + 1
        return JsonResponse({'status': 'success', 'new_exp': avatar.points % 100, 'level': new_lv})
    # =========================
# 共通ロジック：経験値とレベルの計算
# =========================
def get_user_stats(user):
    """
    予定の重みとAvatarのポイントを合算して現在のレベルを算出する共通関数
    """
    # 1. 予定からの経験値（全期間の予定を合算）
    all_schedules = Schedule.objects.filter(user=user)
    schedule_exp = sum(s.level * 10 for s in all_schedules)

    # 2. ボタン等で直接貯めたポイント（Avatarモデル）
    avatar, _ = Avatar.objects.get_or_create(user=user)
    extra_exp = avatar.points

    # 合計経験値
    total_exp = schedule_exp + extra_exp
    
    # 100EXPごとに1レベルアップ
    current_lv = (total_exp // 100) + 1
    display_exp = total_exp % 100
    
    return current_lv, display_exp

# =========================
# カレンダー表示（修正版）
# =========================
@login_required
def calendar_view(request, year=None, month=None):
    today = date.today()
    year = int(year) if year else today.year
    month = int(month) if month else today.month

    cal = calendar.Calendar(firstweekday=6)
    month_days = cal.monthdayscalendar(year, month)

    # 前月・次月の計算（省略せず維持）
    if month == 1: prev_year, prev_month = year - 1, 12
    else: prev_year, prev_month = year, month - 1
    if month == 12: next_year, next_month = year + 1, 1
    else: next_year, next_month = year, month + 1

    # ★統合された経験値計算を呼び出す
    current_lv, display_exp = get_user_stats(request.user)

    # 表示用の予定を取得（今月分のみ）
    schedule_queryset = Schedule.objects.filter(
        user=request.user, 
        date__year=year, 
        date__month=month
    )

    schedules = {}
    for s in schedule_queryset:
        day = s.date.day
        if day not in schedules:
            schedules[day] = []
        schedules[day].append(s)

    context = {
        'calendar': month_days,
        'year': year, 'month': month, 'today': today,
        'prev_year': prev_year, 'prev_month': prev_month,
        'next_year': next_year, 'next_month': next_month,
        'schedules': schedules,
        'current_lv': current_lv,   # 合算レベル
        'display_exp': display_exp, # 合算ゲージ
    }
    return render(request, 'users/calendar.html', context)

# =========================
# 経験値獲得API（修正版）
# =========================
def gain_exp_api(request):
    if request.method == 'POST':
        avatar, _ = Avatar.objects.get_or_create(user=request.user)
        
        # データベースにポイントを保存
        avatar.points += 20 
        avatar.save()
        
        # ★最新の「合算」ステータスを取得して返す
        current_lv, display_exp = get_user_stats(request.user)
        
        return JsonResponse({
            'status': 'success', 
            'new_exp': display_exp, 
            'level': current_lv
        })