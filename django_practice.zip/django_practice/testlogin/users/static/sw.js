// static/sw.js
self.addEventListener('push', function(event) {
    const data = event.data.json();
    const options = {
        body: data.body,
        icon: '/static/icon.png', // 通知用のアイコンがあれば
        badge: '/static/badge.png'
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});