# users/models.py
from django.db import models
from django.contrib.auth.models import User

class Schedule(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE) # 誰の予定か
    title = models.CharField(max_length=200)               # 予定名
    description = models.TextField(blank=True)             # 詳細
    date = models.DateField()                              # 日付
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class Avatar(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # 顔のパーツ（今回は固定ですが、データとして残しておいても邪魔になりません）
    face_type = models.IntegerField(default=1)
    eye_type = models.IntegerField(default=1)
    mouth_type = models.IntegerField(default=1)
    
    # 【ここを追記！】服と背景の保存場所
    clothes_type = models.IntegerField(default=1)
    back_type = models.IntegerField(default=1)
    
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s Avatar"