import calendar
from datetime import date
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.contrib.auth.views import PasswordResetView
from django.contrib.auth.decorators import login_required
# 一番上のインポートに追加
from django.contrib.auth import logout # ←これを追加

# モデルとフォームのインポート
from .models import Avatar, Schedule
from .forms import SignUpForm

# 共通のリダイレクト先
REDIRECT_URL = '/calendar/'

# =========================
# 認証系 (ログイン・新規登録)
# =========================

def index(request):
    """ログイン画面"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect(REDIRECT_URL)
        else:
            return render(request, 'users/login.html', {
                'error': 'ユーザー名かパスワードが間違っています'
            })
    return render(request, 'users/login.html')

def home(request):
    """ホーム画面の交通整理"""
    if request.user.is_authenticated:
        return redirect(REDIRECT_URL)
    return redirect('login')

def signup(request):
    """新規登録"""
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect(REDIRECT_URL)
    else:
        form = SignUpForm()
    return render(request, 'users/signup.html', {'form': form})

# --- 中略 ---

@login_required
def logout_view(request):
    """ログアウト処理"""
    logout(request)
    return redirect('login') # ログアウトしたらログイン画面へ

# =========================
# カレンダー・予定管理
# =========================

@login_required
def calendar_view(request, year=None, month=None):
    """カレンダー表示（予定の読み込み）"""
    today = date.today()
    year = int(year) if year else today.year
    month = int(month) if month else today.month

    cal = calendar.Calendar(firstweekday=6)
    month_days = cal.monthdayscalendar(year, month)

    if month == 1:
        prev_year, prev_month = year - 1, 12
    else:
        prev_year, prev_month = year, month - 1
        
    if month == 12:
        next_year, next_month = year + 1, 1
    else:
        next_year, next_month = year, month + 1

    # 今月の予定を取得
    schedule_queryset = Schedule.objects.filter(
        user=request.user, 
        date__year=year, 
        date__month=month
    )

    schedules = {}
    for s in schedule_queryset:
        day = s.date.day
        if day not in schedules:
            schedules[day] = []
        schedules[day].append(s)

    context = {
        'calendar': month_days,
        'year': year,
        'month': month,
        'today': today,
        'prev_year': prev_year, 'prev_month': prev_month,
        'next_year': next_year, 'next_month': next_month,
        'schedules': schedules,
    }
    return render(request, 'users/calendar.html', context)

@login_required
def add_schedule(request):
    """予定を新規保存"""
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('detail')
        date_str = request.POST.get('date')

        if title and date_str:
            Schedule.objects.create(
                user=request.user,
                title=title,
                description=description,
                date=date_str
            )
    return redirect('calendar')

@login_required
def schedule_detail(request, pk):
    """予定の詳細表示 (HTML)"""
    # ここを JsonResponse から render に変更
    schedule = get_object_or_404(Schedule, pk=pk, user=request.user)
    return render(request, 'users/schedule_detail.html', {'schedule': schedule})

@login_required
def update_schedule(request):
    """予定の更新処理"""
    if request.method == 'POST':
        schedule_id = request.POST.get('id')
        schedule = get_object_or_404(Schedule, id=schedule_id, user=request.user)
        
        schedule.title = request.POST.get('title')
        schedule.description = request.POST.get('detail') 
        schedule.save()
        
    return redirect('calendar')

@login_required
def delete_schedule(request, pk):
    """予定の削除処理"""
    if request.method == 'POST':
        schedule = get_object_or_404(Schedule, pk=pk, user=request.user)
        schedule.delete()
    return redirect('calendar')

# =========================
# その他機能
# =========================

@login_required
def avatar_edit(request):
    """アバター編集"""
    avatar, created = Avatar.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        avatar.back_type = request.POST.get('back_type', 1)
        avatar.clothes_type = request.POST.get('clothes_type', 1)
        avatar.face_type = request.POST.get('face_type', 1)
        avatar.save()
        return redirect(REDIRECT_URL)
    return render(request, 'users/avatar_edit.html', {'avatar': avatar})

def check_username(request):
    """ユーザー名重複チェック"""
    username = request.GET.get("username", "").strip()
    exists = User.objects.filter(username=username).exists()
    return JsonResponse({"exists": exists})

class CustomPasswordResetView(PasswordResetView):
    """パスワード再設定"""
    template_name = 'users/password_reset.html'
    success_url = '/password_reset/done/'

    def form_valid(self, form):
        email = form.cleaned_data['email']
        try:
            user = User.objects.get(email=email)
            self.request.session['reset_username'] = user.username
        except User.DoesNotExist:
            self.request.session['reset_username'] = None
        return super().form_valid(form)