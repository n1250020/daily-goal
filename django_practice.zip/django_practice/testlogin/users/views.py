import calendar
from datetime import date
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.contrib.auth.views import PasswordResetView
from django.contrib.auth.decorators import login_required
from .models import Avatar
from .forms import SignUpForm

# 共通のリダイレクト先URL（相手のPCのカレンダー）
REDIRECT_URL = 'http://10.17.7.127:8000/'

# =========================
# ログイン画面
# =========================
def index(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            # 相手のPCのカレンダーへ飛ぶ
            return redirect(REDIRECT_URL)
        else:
            return render(request, 'users/login.html', {
                'error': 'ユーザー名かパスワードが間違っています'
            })

    return render(request, 'users/login.html')

# =========================
# ホーム画面
# =========================
def home(request):
    if request.user.is_authenticated:
        # 相手のPCのカレンダーへ飛ぶ
        return redirect(REDIRECT_URL)
    return redirect('login')

# =========================
# 新規登録
# =========================
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            # 相手のPCのカレンダーへ飛ぶ
            return redirect(REDIRECT_URL)
    else:
        form = SignUpForm()
    return render(request, 'users/signup.html', {'form': form})

# =========================
# アバター編集
# =========================
@login_required
def avatar_edit(request):
    avatar, created = Avatar.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        avatar.back_type = request.POST.get('back_type', 1)
        avatar.clothes_type = request.POST.get('clothes_type', 1)
        avatar.face_type = request.POST.get('face_type', 1)
        avatar.save()
        
        # 保存後は相手のPCのカレンダーへ戻る
        return redirect(REDIRECT_URL)

    return render(request, 'users/avatar_edit.html', {'avatar': avatar})

# =========================
# カレンダー表示（自分のPC内での確認用）
# =========================
@login_required
def calendar_view(request, year=None, month=None):
    today = date.today()
    
    year = int(year) if year else today.year
    month = int(month) if month else today.month

    cal = calendar.Calendar(firstweekday=6)
    month_days = cal.monthdayscalendar(year, month)

    if month == 1:
        prev_year, prev_month = year - 1, 12
    else:
        prev_year, prev_month = year, month - 1
        
    if month == 12:
        next_year, next_month = year + 1, 1
    else:
        next_year, next_month = year, month + 1

    schedules = {} 

    context = {
        'calendar': month_days,
        'year': year,
        'month': month,
        'today': today,
        'prev_year': prev_year, 'prev_month': prev_month,
        'next_year': next_year, 'next_month': next_month,
        'schedules': schedules,
    }
    return render(request, 'users/calendar.html', context)

# 予定追加・詳細（枠だけ維持）
@login_required
def add_schedule(request):
    return redirect(REDIRECT_URL)

@login_required
def schedule_detail(request, pk):
    return JsonResponse({"message": "詳細画面は準備中"})

# =========================
# ユーザー名重複チェック（Ajax）
# =========================
def check_username(request):
    username = request.GET.get("username", "").strip()
    exists = User.objects.filter(username=username).exists()
    return JsonResponse({"exists": exists})

# =========================
# パスワード再設定
# =========================
class CustomPasswordResetView(PasswordResetView):
    template_name = 'users/password_reset.html'
    success_url = '/password_reset/done/'

    def form_valid(self, form):
        email = form.cleaned_data['email']
        try:
            user = User.objects.get(email=email)
            self.request.session['reset_username'] = user.username
        except User.DoesNotExist:
            self.request.session['reset_username'] = None
        return super().form_valid(form)