# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

class Notifications(models.Model):
    # 1. IDフィールドを追加 (primary_key=True が必須)
    id = models.AutoField(primary_key=True)
    
    user_id = models.IntegerField()
    message = models.TextField()
    scheduled_at = models.DateTimeField()
    
    # 2. 0/1をTrue/Falseとして扱うように変更
    # もし相手のDBが0/1なら、default=Falseを入れておくと安心です
    is_sent = models.BooleanField(default=False)

    class Meta:
        managed = False  # Django側からテーブル構造を変更しない設定
        db_table = 'notifications'

    def __str__(self):
        return f"User {self.user_id}: {self.message[:20]}"