from flask import Flask, render_template, request, redirect, url_for
import calendar
import datetime

app = Flask(__name__)

import sqlite3

def save_to_db(date, title):
    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT,
            title TEXT
        )
    """)
    cur.execute("INSERT INTO schedule (date, title) VALUES (?, ?)", (date, title))
    conn.commit()
    conn.close()

def load_from_db(year, month):
    conn = sqlite3.connect("schedule.db")
    cur = conn.cursor()
    cur.execute("""
        SELECT date, title FROM schedule
        WHERE date LIKE ?
    """, (f"{year:04d}-{month:02d}-%",))
    rows = cur.fetchall()
    conn.close()

    # {"2025-02-03": ["会議", "買い物"], ...} のように整形
    schedule_dict = {}
    for date, title in rows:
        schedule_dict.setdefault(date, []).append(title)

    return schedule_dict

@app.route("/")
@app.route("/<int:year>/<int:month>")
def index(year=None, month=None):

    # 今日の日付
    today = datetime.date.today()

    # 年月が指定されていなければ今月
    if year is None or month is None:
        year = today.year
        month = today.month

    # カレンダー生成（日曜始まり）
    cal = calendar.Calendar(calendar.SUNDAY).monthdayscalendar(year, month)

    # 前月・翌月計算
    prev_year, prev_month = year, month - 1
    next_year, next_month = year, month + 1

    if prev_month == 0:
        prev_month = 12
        prev_year -= 1

    if next_month == 13:
        next_month = 1
        next_year += 1

    schedules = load_from_db(year, month)

    return render_template(
        "calendar.html",
        calendar=cal,
        year=year,
        month=month,
        prev_year=prev_year,
        prev_month=prev_month,
        next_year=next_year,
        next_month=next_month,
        today=today,
        schedules=schedules
    )

@app.route("/add_schedule", methods=["POST"])
def add_schedule():
    date = request.form.get("date")   # "2025-02-03" のような文字列
    title = request.form.get("title") # 入力された予定名

    print("受け取った日付:", date)
    print("受け取った予定名:", title)

    save_to_db(date, title)

    # 予定を追加した日付の月へ戻る
    year, month, _ = map(int, date.split("-"))
    return redirect(url_for("index", year=year, month=month))

if __name__ == "__main__":
    app.run(debug=True)